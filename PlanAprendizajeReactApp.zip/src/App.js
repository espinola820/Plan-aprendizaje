import React, { useState } from "react";

const plan = [
  {
    title: "Semana 1–2: Diseño de Videojuegos",
    description:
      "Aprende fundamentos de diseño de juegos. Crea el Game Design Document.",
    resources: [
      { name: "Game Design Theory - Coursera", url: "https://www.coursera.org/learn/game-design" },
      { name: "Libro: The Art of Game Design", url: "https://www.amazon.com/Art-Game-Design-Lenses-Third/dp/1138632058" }
    ]
  },
  {
    title: "Semana 3–4: Unity y C#",
    description:
      "Domina Unity 3D y C#. Crea tu primer prototipo de juego 3D.",
    resources: [
      { name: "Unity Learn – Junior Programmer", url: "https://learn.unity.com/pathway/junior-programmer" },
      { name: "Udemy: Unity Developer Course", url: "https://www.udemy.com/course/unitycourse/" }
    ]
  },
  {
    title: "Semana 5–6: Blender y Animación",
    description:
      "Modela y anima personajes 3D con Blender.",
    resources: [
      { name: "Blender Guru (YouTube)", url: "https://www.youtube.com/playlist?list=PLjEaoINr3zgFX8ZsChQVQsuDSjEqdWMAD" },
      { name: "Udemy: Blender para Unity", url: "https://www.udemy.com/course/blender-character-creator-for-unity/" }
    ]
  },
  {
    title: "Semana 7–8: Multijugador en Unity",
    description:
      "Implementa partidas online 2vs2 con Photon o Netcode.",
    resources: [
      { name: "Photon Fusion - YouTube", url: "https://www.youtube.com/c/DilmerValecillos" },
      { name: "Udemy: Multiplayer con Photon", url: "https://www.udemy.com/course/multiplayer-game-development-with-photon-unity/" }
    ]
  },
  {
    title: "Semana 9–10: Lógica de Apuestas",
    description:
      "Sistema de apuestas internas con puntos. Simulación de lógica de dinero.",
    resources: []
  },
  {
    title: "Semana 11–12: Backend y Base de Datos",
    description:
      "Autenticación, almacenamiento de usuarios, partidas y wallet.",
    resources: [
      { name: "Firebase para Unity", url: "https://www.youtube.com/watch?v=TOEi6T2mtHo" },
      { name: "React + Firebase", url: "https://www.udemy.com/course/react-firebase/" }
    ]
  },
  {
    title: "Semana 13–15: Página Web con React",
    description:
      "Desarrolla la página web para login, apuestas y panel de usuario.",
    resources: [
      { name: "React FreeCodeCamp", url: "https://www.youtube.com/watch?v=bMknfKXIFA8" },
      { name: "Next.js Learn", url: "https://nextjs.org/learn" }
    ]
  },
  {
    title: "Semana 16–18: Pagos Reales",
    description:
      "Integra Stripe y PayPal en modo test.",
    resources: [
      { name: "Stripe + React", url: "https://www.youtube.com/watch?v=9V1tlhGjSMk" },
      { name: "PayPal Docs", url: "https://developer.paypal.com/docs/" }
    ]
  },
  {
    title: "Semana 19–20: Legalidad de Apuestas",
    description:
      "Consulta sobre licencias, leyes locales y regulación.",
    resources: [
      { name: "GamblingLicenses.com", url: "https://www.gamblinglicenses.com/" },
      { name: "Law Stack Exchange", url: "https://law.stackexchange.com/" }
    ]
  },
  {
    title: "Semana 21–22: Seguridad y Legalidad de Datos",
    description:
      "Aprende sobre KYC, protección de datos y GDPR.",
    resources: [
      { name: "Curso de Ciberseguridad (Google/Coursera)", url: "https://www.coursera.org/specializations/it-security" }
    ]
  }
];

export default function App() {
  const [completed, setCompleted] = useState(Array(plan.length).fill(false));

  const toggleComplete = (index) => {
    const newCompleted = [...completed];
    newCompleted[index] = !newCompleted[index];
    setCompleted(newCompleted);
  };

  return (
    <div style={{ padding: 20 }}>
      {plan.map((item, index) => (
        <div key={index} className="card">
          <h2>{item.title}</h2>
          <p>{item.description}</p>
          <ul>
            {item.resources.map((res, i) => (
              <li key={i}>
                <a href={res.url} target="_blank" rel="noreferrer">{res.name}</a>
              </li>
            ))}
          </ul>
          <button onClick={() => toggleComplete(index)}>
            {completed[index] ? "✔ Completado" : "Marcar como Completado"}
          </button>
        </div>
      ))}
    </div>
  );
}